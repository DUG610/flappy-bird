# -*- coding: utf-8 -*-
import pygame
from random import randint
import json
import urllib.request
import asyncio
import platform
import sys

USER_ID = "1140424741509931079"

pygame.init()
pygame.font.init()
screen = pygame.display.set_mode((600,600))
pygame.display.set_caption("hoinon321")
clock = pygame.time.Clock()
font_to = pygame.font.Font(None, 50)
font_nho =pygame.font.Font(None,30)
khoang_trong = 100
try:
    img_bg=pygame.image.load('background.png')
    img_bird=pygame.image.load('hoinon321.png')
    img_pipe=pygame.image.load('pipe.png')
except pygame.error as e:
    print("Tai anh bi loi")
    pygame.quit()
    exit()
def reset_game():
    global cot_1x,cot_2x,cot_3x,cot_4x
    global cot_1y,cot_2y,cot_3y,cot_4y
    global chim_y,gravity,speed,van_toc_chim_roi_ban_dau,game_over,score
#cot x
    cot_1x=400
    cot_2x=600
    cot_3x=800
    cot_4x=1000
#cot y
    cot_1y = randint(150,350)
    cot_2y = randint(150,350)
    cot_3y = randint(150,350)
    cot_4y = randint(150,350)
# khoan trong,spee
    speed =3
#gravity
    chim_y=200
    van_toc_chim_roi_ban_dau = 0.3
    gravity = 1
    game_over = False
    score=0
    sent_score=False #gui diem ve sever
def send_coins_to_bot(user_id, coins):
    try:
        url = "http://127.0.0.1:8000/api/add-coins"
        payload = f'{{"user_id": "{user_id}", "coins": {coins}}}'

        # Sử dụng Javascript fetch qua WebAssembly
        if platform.system() == "Emscripten":
            platform.window.fetch(
                url,
                {
                    "method": "POST",
                    "headers": {"Content-Type": "application/json"},
                    "body": payload,
                },
            )
            print(f"Da gui {coins} xu") # Log ra console trình duyệt
        else:
             # Logic test cục bộ nếu cần
             print(f"Loi goi API cuc bo (Urllib da bi loai bo)")
             
    except Exception as e:
        print(f"Loi gui xu: {e}")
reset_game()
tang_speed = 0.001

# Vòng lặp chính chuẩn Asyncio cho Web

async def main():
    global speed, cot_1x, cot_2x, cot_3x, cot_4x, cot_1y, cot_2y, cot_3y, cot_4y
    global gravity, chim_y, game_over, score, sent_score
# 3. Vòng lặp chính của game (Game Loop)
    running = True
    while running:
       clock.tick(60)
# Xử lý các sự kiện (bàn phím, chuột, đóng cửa sổ)
       for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE and not game_over:
                    gravity = -5
                    print(chim_y)
                elif event.key == pygame.K_SPACE and game_over:
                    reset_game()

        # Vẽ hình nền
       screen.blit(img_bg, (0, 0))
       if not game_over:
         speed+=tang_speed
         cot_1x -= speed
         cot_2x -= speed
         cot_3x -= speed
         cot_4x -= speed
         if cot_1x <=-50:
            cot_1x=750
            cot_1y = randint(150,350)
         if cot_2x <=-50:
            cot_2x= 750
            cot_2y = randint(150,350)
         if cot_3x <=-50:
            cot_3x=750
            cot_3y = randint(150,350)
         if cot_4x <=-50:
            cot_4x=750
            cot_4y = randint(150,350)
         gravity += van_toc_chim_roi_ban_dau
         chim_y += gravity
#cot tren
# cắt phần đầu cột
       COT_RONG = 70
       COT_CAO = 138
       HITBOX_RONG = 50
        # Khung Rect ẩn tính va chạm HITBOX
       cot1_tren = pygame.Rect(cot_1x+20, 0, HITBOX_RONG , cot_1y)
       cot2_tren = pygame.Rect(cot_2x+20, 0, HITBOX_RONG, cot_2y)
       cot3_tren = pygame.Rect(cot_3x+20, 0, HITBOX_RONG, cot_3y)
       cot4_tren = pygame.Rect(cot_4x+20, 0, HITBOX_RONG, cot_4y)

       cot1_duoi = pygame.Rect(cot_1x+20, cot_1y + 150, HITBOX_RONG, 450 - cot_1y)
       cot2_duoi = pygame.Rect(cot_2x+20, cot_2y + 150, HITBOX_RONG, 450 - cot_2y)
       cot3_duoi = pygame.Rect(cot_3x+20, cot_3y + 150, HITBOX_RONG, 450 - cot_3y)
       cot4_duoi = pygame.Rect(cot_4x+20, cot_4y + 150, HITBOX_RONG, 450 - cot_4y)

        # 2. Chuẩn bị hình ảnh
       img_cot = pygame.transform.scale(img_pipe, (COT_RONG, COT_CAO))

    # Cắt riêng phần THÂN CỘT ở giữa (loại bỏ đỉnh và chân để xếp không bị trùng)
        # Lấy khoảng 60% phần giữa của ảnh
       than_cot = img_cot.subsurface((0, 30, COT_RONG, 70))
       dau_cot = img_cot.subsurface((0, 30, COT_RONG, 108))   #0: là vị trí x bắt đầu cắt; 30 là vị trí y bắt đầu cắt; COT_RONG là chiều rộng cột; 108 là vị trí cuối từ điểm y=30 (Kophai 138) sao cho 
       than_cot_flip = pygame.transform.flip(than_cot, False, True)
       dit_cot_tren = pygame.transform.flip(dau_cot, False, False)
       dau_cot_duoi = pygame.transform.flip(dau_cot, False, True)
        # 3. Vẽ 4 cặp cột
       danh_sach_cot = [(cot_1x, cot_1y), (cot_2x, cot_2y), (cot_3x, cot_3y), (cot_4x, cot_4y)]
       for cx, cy in danh_sach_cot:
    # --- CỘT TRÊN ---
    # 1. Vẽ đầu cột ở điểm hở cy
           screen.blit(dit_cot_tren, (cx, cy - 108))
    # 2. Xếp phần thân cột kéo dài lên mép trên màn hình
           y_temp = cy - 108-70
           while y_temp + 70 > 0:
               screen.blit(than_cot_flip, (cx, y_temp))
               y_temp -= 70

    # --- CỘT DƯỚI ---
    # 1. Vẽ đầu cột ở điểm hở cy + 150
           screen.blit(dau_cot_duoi, (cx, cy + 150))
    # 2. Xếp phần thân cột kéo dài xuống đáy màn hình
           y_temp = cy + 150 + 108
           while y_temp < 600:
               screen.blit(than_cot, (cx, y_temp))
               y_temp += 70
    # ve con chim
       bird_rect=pygame.draw.rect(screen,(255,255,0),(100,chim_y,40,40))
       screen.blit(img_bird, (100, chim_y))
    #tinh diem
       if bird_rect.colliderect(cot1_tren) or bird_rect.colliderect(cot2_tren) or bird_rect.colliderect(cot3_tren) or bird_rect.colliderect(cot4_tren) or bird_rect.colliderect(cot1_duoi) or bird_rect.colliderect(cot2_duoi) or bird_rect.colliderect(cot3_duoi) or bird_rect.colliderect(cot4_duoi) or chim_y >560 or chim_y <=0:
          game_over = True
          if not sent_score and score > 0:
                   send_coins_to_bot(USER_ID, score)
                   sent_score = True
       if 97<cot_1x<=100 or 97<cot_2x<=100 or 97<cot_3x<=100 or 97<cot_4x<=100:
          score +=1
    #point
       text_score =font_nho.render(f"Score: {score}", True, (255, 0, 0))
       screen.blit(text_score, (10, 10))
       if game_over:
           game_over =font_to.render(f"Game over", True, (255, 0, 0))
           screen.blit(game_over, (200, 200))
           SPACE =font_nho.render(f"Space to cotinue", True, (255, 0, 0))
           screen.blit(SPACE, (210, 260))
       pygame.display.flip()
       await asyncio.sleep(0)

# 4. Thoát pygame khi vòng lặp kết thúc
    pygame.quit()
asyncio.run(main())
